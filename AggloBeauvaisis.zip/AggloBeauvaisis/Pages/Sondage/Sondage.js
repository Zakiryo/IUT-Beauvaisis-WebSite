function regime(aliments, sondage) {
    let alimSondage = [];
    for (let i = 1; i < 11; ++i) {
        alimSondage.push(sondage[`Aliment${i}`]);
    }
    for (let i = 0; i < alimSondage.length; ++i) {
        for (let j = 0; j < aliments.length; ++j) {
            if (alimSondage[i] === aliments[j].alim_code) {
                if ((aliments[j].alim_ssgrp_code >= 401 && aliments[j].alim_ssgrp_code <= 404) || (aliments[j].alim_nom_fr.includes('viande')) || (aliments[j].alim_nom_fr.includes('poisson')) || (aliments[j].alim_ssssgrp_code >= 10301 && aliments[j].alim_ssssgrp_code <= 10305)) {
                    return "Carnivore";
                }
            }
        }
    }
    return estVegetalien(aliments, alimSondage);
}

function estVegetalien(aliments, alimSondage) {
    for (let i = 0; i < alimSondage.length; ++i) {
        for (let j = 0; j < aliments.length; ++j) {
            if (alimSondage[i] === aliments[j].alim_code) {
                if ((aliments[j].alim_grp_code === 4) || (aliments[j].alim_grp_code === 5) || (aliments[j].alim_ssgrp_code === 410) || (aliments[j].alim_ssssgrp_code === 10308) || (aliments[j].alim_nom_fr.includes('fromage')) || (aliments[j].alim_ssgrp_code === 801) || (aliments[j].Lactose_g_100_g !== '<_0.1')) {
                    return "Végétarien";
                }
            }
        }
    }
    return "Végétalien";
}

function scoreSante(aliments, sondage) {
    let score = 1000;
    let alimSondage = [];
    for (let i = 1; i < 11; ++i) {
        alimSondage.push(sondage[`Aliment${i}`]);
    }
    for (let i = 0; i < alimSondage.length; ++i) {
        for (let j = 0; j < aliments.length; ++j) {
            if (alimSondage[i] === aliments[j].alim_code) {
                if (aliments[j].Cholestérol_mg_100_g > 10) {
                    score -= parseInt(aliments[j].Cholestérol_mg_100_g / 10);
                }
                if (aliments[j].AG_saturés_g_100_g > 5) {
                    score -= parseInt(aliments[j].AG_saturés_g_100_g / 5);
                }
                if (aliments[j].Energie_Règlement_UE_N_1169_2011_kcal_100_g > 100) {
                    score -= parseInt(aliments[j].Energie_Règlement_UE_N_1169_2011_kcal_100_g / 5);
                }
                if (aliments[j].alim_grp_code === 7) {
                    score -= parseInt(aliments[j].Sucres_g_100_g / 5);
                }
            }
        }
    }
    return score;
}

function addColumn(aliments, sondage) {
    for (let i = 0; i < sondage.length; ++i) {
        let tr = document.createElement("tr");
        let tdID = document.createElement("td");
        let tdNom = document.createElement("td");
        let tdPrenom = document.createElement("td");
        let tdDate = document.createElement("td");
        let tdVille = document.createElement("td");
        let tdRegime = document.createElement("td");
        let tdScore = document.createElement("td");
        tdID.innerHTML = sondage[i].ID;
        tdNom.innerHTML = sondage[i].Nom;
        tdPrenom.innerHTML = sondage[i].Prénom;
        tdDate.innerHTML = sondage[i].Naissance;
        tdVille.innerHTML = sondage[i].Ville;
        tdRegime.innerHTML = regime(aliments, sondage[i]);
        tdScore.innerHTML = scoreSante(aliments, sondage[i]) + ' / 1000';
        document.getElementById("tbody").appendChild(tr);
        document.getElementById("tbody").appendChild(tdID);
        document.getElementById("tbody").appendChild(tdNom);
        document.getElementById("tbody").appendChild(tdPrenom);
        document.getElementById("tbody").appendChild(tdDate);
        document.getElementById("tbody").appendChild(tdVille);
        document.getElementById("tbody").appendChild(tdRegime);
        document.getElementById("tbody").appendChild(tdScore);
    }
}

fetch('Aliments.json')
    .then(reponse => reponse.json())
    .then(aliments => {
        fetch('Sondage.json')
            .then(reponse => reponse.json())
            .then(sondage => {
                addColumn(aliments, sondage);

            })
    })
